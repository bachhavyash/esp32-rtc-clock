/*
 * ESP32 Real-Time Clock Display
 * Hardware: ESP32-WROOM-32 + DS3231 RTC (I2C) + 4-Digit 7-Segment Display
 * Author: Yash Bachhav
 * Description: Reads time from DS3231 RTC module over I2C and displays
 *              HH:MM format on a 4-digit 7-segment display using shift registers.
 */

#include <Wire.h>
#include <RTClib.h>

// ── DS3231 RTC ──────────────────────────────────────────────
RTC_DS3231 rtc;

// ── 7-Segment (74HC595 Shift Register) Pins ─────────────────
#define DATA_PIN   23   // SER  (DS)
#define LATCH_PIN  22   // RCLK (ST_CP)
#define CLOCK_PIN  21   // SRCLK (SH_CP)

// ── Digit Select Pins (Common Cathode, LOW = ON) ─────────────
#define DIGIT1  19   // Tens of Hours
#define DIGIT2  18   // Units of Hours
#define DIGIT3   5   // Tens of Minutes
#define DIGIT4   4   // Units of Minutes

// ── 7-Segment Encoding (a-b-c-d-e-f-g, active HIGH) ─────────
// Segments: abcdefg (bit7=a, bit0=g, bit6=dp — dp always off)
const uint8_t segDigits[10] = {
  0b11111100,  // 0
  0b01100000,  // 1
  0b11011010,  // 2
  0b11110010,  // 3
  0b01100110,  // 4
  0b10110110,  // 5
  0b10111110,  // 6
  0b11100000,  // 7
  0b11111110,  // 8
  0b11110110   // 9
};

const uint8_t SEG_COLON = 0b00000010;  // Only dp segment ON for colon blink

int digitPins[4] = {DIGIT1, DIGIT2, DIGIT3, DIGIT4};
int displayDigits[4] = {0, 0, 0, 0};  // HH:MM digits
bool colonOn = true;
unsigned long lastColonToggle = 0;
unsigned long lastRTCRead = 0;

// ── Setup ────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("ESP32 RTC Clock Starting...");

  // I2C for DS3231
  Wire.begin(26, 27);  // SDA=GPIO26, SCL=GPIO27

  if (!rtc.begin()) {
    Serial.println("ERROR: DS3231 not found! Check wiring.");
    while (1) delay(100);
  }

  // If RTC lost power, set to compile time
  if (rtc.lostPower()) {
    Serial.println("RTC lost power — setting to compile time.");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  // Shift register pins
  pinMode(DATA_PIN,  OUTPUT);
  pinMode(LATCH_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);

  // Digit select pins
  for (int i = 0; i < 4; i++) {
    pinMode(digitPins[i], OUTPUT);
    digitalWrite(digitPins[i], HIGH);  // All OFF initially
  }

  Serial.println("RTC OK. Display running.");
}

// ── Write byte to 74HC595 ────────────────────────────────────
void shiftWrite(uint8_t data) {
  digitalWrite(LATCH_PIN, LOW);
  shiftOut(DATA_PIN, CLOCK_PIN, MSBFIRST, data);
  digitalWrite(LATCH_PIN, HIGH);
}

// ── Display one digit (multiplexed) ─────────────────────────
void showDigit(int pos, uint8_t segData) {
  // Turn all digits off
  for (int i = 0; i < 4; i++) digitalWrite(digitPins[i], HIGH);

  shiftWrite(segData);

  // Turn on selected digit
  digitalWrite(digitPins[pos], LOW);
  delayMicroseconds(2000);  // 2ms per digit for persistence of vision

  // Turn off
  digitalWrite(digitPins[pos], HIGH);
}

// ── Read RTC and update displayDigits[] ──────────────────────
void updateTimeFromRTC() {
  DateTime now = rtc.now();
  int h = now.hour();
  int m = now.minute();

  displayDigits[0] = h / 10;
  displayDigits[1] = h % 10;
  displayDigits[2] = m / 10;
  displayDigits[3] = m % 10;

  Serial.printf("Time: %02d:%02d:%02d | Temp: %.1f C\n",
                h, m, now.second(), rtc.getTemperature());
}

// ── Main Loop ────────────────────────────────────────────────
void loop() {
  unsigned long now = millis();

  // Read RTC every second
  if (now - lastRTCRead >= 1000) {
    updateTimeFromRTC();
    lastRTCRead = now;
  }

  // Toggle colon every 500ms
  if (now - lastColonToggle >= 500) {
    colonOn = !colonOn;
    lastColonToggle = now;
  }

  // Multiplex all 4 digits continuously
  showDigit(0, segDigits[displayDigits[0]]);
  showDigit(1, segDigits[displayDigits[1]] | (colonOn ? SEG_COLON : 0));
  showDigit(2, segDigits[displayDigits[2]]);
  showDigit(3, segDigits[displayDigits[3]]);
}
