# Gerber Files — ESP32 RTC Clock PCB

These Gerber files are exported from EasyEDA and are ready for fabrication at JLCPCB, PCBWay, or any standard PCB manufacturer.

## Files

| File | Layer | Description |
|------|-------|-------------|
| `esp32_rtc_clock-F_Cu.gtl` | Top Copper | Signal traces, component pads (top layer) |
| `esp32_rtc_clock-B_Cu.gbl` | Bottom Copper | GND pour (bottom layer) |
| `esp32_rtc_clock-F_SilkS.gto` | Top Silkscreen | Component labels, reference designators |
| `esp32_rtc_clock-B_SilkS.gbo` | Bottom Silkscreen | Board info |
| `esp32_rtc_clock-F_Mask.gts` | Top Solder Mask | Solder mask openings (top) |
| `esp32_rtc_clock-B_Mask.gbs` | Bottom Solder Mask | Solder mask openings (bottom) |
| `esp32_rtc_clock-Edge_Cuts.gm1` | Board Outline | PCB boundary / dimensions |
| `esp32_rtc_clock.drl` | Drill File | Via and through-hole drill positions |

## PCB Specs

| Parameter | Value |
|-----------|-------|
| Board Size | ~80mm x 60mm |
| Layers | 2 |
| Thickness | 1.6mm |
| Copper Weight | 1 oz |
| Surface Finish | HASL (lead-free) |
| Min Trace Width | 0.2mm |
| Min Clearance | 0.2mm |

## How to Order (JLCPCB)

1. Zip all files in this folder
2. Go to [jlcpcb.com](https://jlcpcb.com)
3. Click "Order Now" → Upload the zip
4. Select: 2 layers, 1.6mm, green soldermask
5. Minimum order: 5 PCBs (~$2 USD)
