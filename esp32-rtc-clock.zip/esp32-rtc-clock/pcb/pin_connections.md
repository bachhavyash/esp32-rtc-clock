# Pin Connection Reference — ESP32 RTC Clock

## ESP32 ↔ DS3231 (I2C)
| ESP32 Pin | DS3231 Pin | Description       |
|-----------|------------|-------------------|
| GPIO26    | SDA        | I2C Data          |
| GPIO27    | SCL        | I2C Clock         |
| 3.3V      | VCC        | Power             |
| GND       | GND        | Ground            |

> Pull-up resistors: 10K from SDA→3.3V and SCL→3.3V

## ESP32 ↔ 74HC595 (Shift Register for 7-Segment Segments)
| ESP32 Pin | 74HC595 Pin | Description        |
|-----------|-------------|--------------------|
| GPIO23    | DS (pin 14) | Serial Data In     |
| GPIO22    | ST_CP (pin 12)| Latch Clock      |
| GPIO21    | SH_CP (pin 11)| Shift Clock      |
| 3.3V      | VCC (pin 16)| Power              |
| GND       | GND (pin 8) | Ground             |
| GND       | OE (pin 13) | Output Enable (active LOW) |
| VCC       | MR (pin 10) | Master Reset (active LOW, tie HIGH) |

## 74HC595 ↔ 7-Segment Display (Segments a–g)
| 74HC595 Output | Segment | 330R Resistor |
|----------------|---------|---------------|
| Q0             | a       | Yes           |
| Q1             | b       | Yes           |
| Q2             | c       | Yes           |
| Q3             | d       | Yes           |
| Q4             | e       | Yes           |
| Q5             | f       | Yes           |
| Q6             | g       | Yes           |
| Q7             | dp      | Yes (colon)   |

## ESP32 ↔ Digit Select (via NPN 2N2222 transistors)
| ESP32 Pin | Transistor | Digit Position |
|-----------|------------|----------------|
| GPIO19    | Q1         | Digit 1 (Hours tens)   |
| GPIO18    | Q2         | Digit 2 (Hours units)  |
| GPIO5     | Q3         | Digit 3 (Minutes tens) |
| GPIO4     | Q4         | Digit 4 (Minutes units)|

> Base resistors: 1K from ESP32 GPIO → transistor base
> Common cathode of each digit connected to collector of NPN transistor → GND
